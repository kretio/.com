// Get the lightbox modal
const lightbox = document.getElementById("lightbox");
const lightboxImg = document.getElementById("lightbox-img");
const closeBtn = document.getElementsByClassName("close")[0];

// Add event listeners to project images
const projectImages = document.querySelectorAll(".project-image");

projectImages.forEach(image => {
    image.addEventListener("click", function() {
        lightbox.style.display = "flex";
        lightboxImg.src = this.getAttribute("data-full");
    });
});

// Close the modal when the user clicks the close button
closeBtn.onclick = function() {
    lightbox.style.display = "none";
};

// Close the modal when the user clicks anywhere outside of the image
window.onclick = function(event) {
    if (event.target === lightbox) {
        lightbox.style.display = "none";
    }
};

class TypeWriter {
    constructor(el, toRotate, period) {
        this.toRotate = toRotate;
        this.el = el;
        this.loopNum = 0;
        this.period = parseInt(period, 10) || 2000;
        this.txt = '';
        this.isDeleting = false;
        this.tick();
    }

    tick() {
        let i = this.loopNum % this.toRotate.length,
            fullTxt = this.toRotate[i],
            delta = 200 - Math.random() * 100;
        this.txt = this.isDeleting ? fullTxt.substring(0, this.txt.length - 1) : fullTxt.substring(0, this.txt.length + 1);
        this.el.innerHTML = `<span class="wrap">${this.txt}</span>`;
        if (this.isDeleting) delta /= 2;
        if (!this.isDeleting && this.txt === fullTxt) {
            delta = this.period;
            this.isDeleting = true;
        } else if (this.isDeleting && this.txt === '') {
            this.isDeleting = false;
            this.loopNum++;
            delta = 500;
        }
        setTimeout(() => this.tick(), delta);
    }
}

window.onload = function() {
    document.querySelectorAll('.typewrite').forEach(el => {
        let toRotate = el.getAttribute('data-type'),
            period = el.getAttribute('data-period');
        if (toRotate) new TypeWriter(el, JSON.parse(toRotate), period);
    });
    let css = document.createElement("style");
    css.type = "text/css";
    css.innerHTML = ".typewrite > .wrap { border-right: 0.08em solid #fff}";
    document.body.appendChild(css);
};
